function populate() {
    "use strict";
    if (quiz.isEnded()) {
        showScores();
    }
        else {
        // show question
            var element = document.getElementById("question");
            element.innerHTML = quiz.getQuestionIndex().text;

        // show options
            var choices = quiz.getQuestionIndex().choices;
        for (var i = 0; i < quiz.questions.length ; i++) {
            var element = document.getElementById("choice" + i);
            element.innerHTML = choices[i];
            guess("btn" + i, choices[i]);
    }

       // showProgress();
    }
};

 function guess(id, guess) {
    var button = document.getElementById(id);
    button.onclick = function() {
        quiz.guess(guess);
        populate();
    }
};

function showScores() {
    var gameOverHTML = "<h1>Result</h1>";
    gameOverHTML += "<h2 id='score'> Your score is " + quiz.score + " / 8" + "</h2>";
    var element = document.getElementById("quiz");
    element.innerHTML = gameOverHTML;
    
    if(quiz.score >= 4 ){
        alert(" Congratulations ! ^_^ \n" + "correct answers\n"+"1-C \n"+"2-Yes \n"
             +"3-4  \n"+"4-java \n"+"5-Java virtual Machine \n"+"6-Never \n"+"7-1995 \n"+" 8-All\n");
    }else
        {
            alert(" Oh No ! You should practice again ! \n" + "Correct Answers\n"+"1-C \n"+"2-Yes \n"
             +"3-4  \n"+"4-java \n"+"5-Java virtual Machine \n"+"6-Never \n"+"7-1995 \n"+" 8-All\n");
        }
};

 function check(){
      if (!quiz.isEnded()) {
        alert("please complete all questions to see correct answers!");
    }
 }

// create questions
var questions = [
    new Question("Which one is not an object oriented programming language?", ["Java", "C#","C++", "C"], "C"),
    new Question(" Is Java an object oriented programming language ?", ["Yes", "No", "other", "never"], "Yes"),
    new Question("There are ____ main components of object oriented programming.", ["1", "6","2", "4"], "4"),
    new Question("Which language is mostly used for Android apps?", ["PHP", "Java", "Javascript", "All"], "Java"),
    new Question("JVM is a ____.", ["Language", "Library", "Framework", "Java virtual Machine"], "Java virtual Machine"),
     new Question("Abstract class in java can be instantiated ?",["Yes","some times","always","Never"],"Never"),
    new Question("Java firstly created in...",["1995","1559","1888","1998"],"1995"),
     new Question("Java can be used in...",["Android Development","Desktop Applications","Web Apps","All"],"All")
];

// create quiz
var quiz = new Quiz(questions);

// display quiz
populate();

  
    





