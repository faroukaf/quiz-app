var imgTrue = document.getElementById('true');
var imgFalse = document.getElementById('false');

function correct() {
  var myWindow = window.open("Answer.html",'popUpWindow',"width=220px,height=220px,menubar=no,location=no");
}

function wrong() {
  var myWindow = window.open("result.html",'popUpWindow',"width=220px,height=220px,menubar=no,location=no");
}

//  document.getElementById("result").innerHTML =count+ " ✔ " ;

